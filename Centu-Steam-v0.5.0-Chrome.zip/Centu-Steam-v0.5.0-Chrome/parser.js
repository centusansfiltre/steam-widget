/* Centu Sans Filtre — lecture locale de la seule fiche ouverte. Aucun réseau. */
(() => {
  'use strict';
  const clean = s => String(s ?? '').replace(/\s+/g, ' ').trim();
  const norm = s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[’‘]/g, "'").toLowerCase().replace(/\b(does|do|did|is|are|was|were|has|have|can|could|would|should|must)n['’]t\b/g,'$1 not');
  const definitions = [
    ['visual','Graphismes','image', /\b(?:artworks?|art|illustrations?|images?|graphics?|graphismes?|graphiques?|textures?|materials?|materiaux|sprites?|portraits?|backgrounds?|arriere[- ]plans?|visuels?|visuals?|2d assets?|3d models?|modeles? 3d)\b/g],
    ['animation','Animation / vidéo','film', /\b(?:animations?|videos?|cinematics?|cinematiques?|cutscenes?|mocap|motion capture|lip[- ]?sync|synchronisation labiale)\b/g],
    ['sound','Musique / bruitages','music', /\b(?:music|musiques?|soundtracks?|bandes?[- ]son|compositions?|sound effects?|effets? sonores?|bruitages?|sfx|sound design|audio|sons?|sounds?|suno|udio)\b/g],
    ['voice','Voix','mic', /\b(?:voices?|voix|voice[- ]?(?:overs?|acting|cloning)|doublages?|narration|speech|text[- ]to[- ]speech|tts|synthese vocale|elevenlabs)\b/g],
    ['text','Textes / scénario','text', /\b(?:texts?|textes?|story|stories|storylines?|histoires?|scenarios?|dialogues?|dialogs?|writing|ecriture|narrative|narratif|descriptions?)\b/g],
    ['translation','Traduction','translate', /\b(?:translations?|traductions?|translat(?:e|ed|ing)|traduit(?:s|es)?|traduire|locali[sz](?:ations?|e|ed|ing)|deepl)\b/g],
    ['code','Code','code', /\b(?:code|coding|programming|programmation|scripts?|scripting|copilot|algorithmes?|algorithms?|debugging|debug|debogage|optimization|optimisation)\b/g],
    ['promotion','Contenu promotionnel','megaphone', /\b(?:promotional|promotionnels?|promotionnelles?|promotion|marketing|capsules?|capsule art|headers?|banners?|bannieres?|trailers?|key art|store(?:front)? (?:page|art|images?|assets?|description)|page (?:de la )?(?:boutique|steam)|visuels? (?:de |du )?(?:magasin|boutique)|press kit|communiques? de presse)\b/g],
    ['runtime','IA pendant la partie','gamepad', /\b(?:runtime|run[- ]time|real[- ]time|temps reel|live[- ]generated|live generation|on[- ]the[- ]fly|a la volee|while (?:the game is )?running|during gameplay|pendant (?:la partie|le jeu)|in[- ]game (?:ai|generation)|ia (?:en jeu|in[- ]game))\b/g],
    ['other','Autres usages','layers', /\b(?:concept art|concepts?|brainstorm(?:ing)?|ideation|prototyp(?:e|es|ing|age)|references?|moodboards?|research|recherche|inspiration|planning|planification|testing|tests?|assurance qualite|documentation|internal tools?|outils? internes?)\b/g]
  ];
  const scopeRE = /\b(?:concept art|moodboards?|brainstorming|ideation|references?|inspiration|prototyp(?:e|es|ing|age))\b/;
  const promoRE = definitions.find(d=>d[0]==='promotion')[3];
  function stateFor(clause, start, end) {
    const s=norm(clause), left=s.slice(0,start), right=s.slice(end);
    const localLeft=left.slice(-150), localRight=right.slice(0,100);
    if(/\bnot all\b|\bpas tous\b/.test(localLeft))return 'uncertain';
    if (/\b(?:no|not|never|without|aucun[e]?|sans|pas|jamais)\b(?:[\s,:-]+[\w'-]+){0,20}[\s,:-]*$/.test(localLeft) && !/\bnot only\b|\bpas seulement\b/.test(localLeft)) return 'denied';
    if (/^\s*[:=(]?\s*(?:%\s*0(?:[.,]0+)?(?![\d.,])|0(?:[.,]0+)?\s*%)/.test(localRight) || /(?:^|\s)%\s*0\s*$/.test(localLeft)) return 'denied';
    if (/\b(?:is|are|was|were|n'est|ne sont|n'ont|n'a)\b.{0,12}\b(?:not|never|pas|jamais)\b/.test(localRight.slice(0,45)) || /^(?:\W+\w+){0,3}\W+(?:hand[- ]?(?:made|drawn)|human[- ]made|faits? main|dessines? a la main)\b/.test(localRight)) return 'denied';
    if (/\b(?:may|might|could|possibly|potentially|peut-etre|pourrait|pourraient|envisage|will use|plan(?:s|ned)? to use|intend(?:s)? to use)\b/.test(localLeft)) return 'uncertain';
    if (/\b(?:have been|were|was|are|ont ete|a ete)\s+(?:fully |entierement )?(?:removed|replaced|retires?|remplaces?)\b/.test(s) && !/\b(?:will|plan|intend|seront|sera|prevu)\b/.test(s)) return 'removed';
    return 'mentioned';
  }
  function classifyAI(raw) {
    const text=String(raw||''), hits=[];
    // Les offsets se réfèrent à chaque extrait d'origine, pas au texte normalisé.
    const sentences=text.replace(/\b(?:[A-Za-z]\.){2,}/g,m=>m.replace(/\./g,'∯')).split(/(?<=[.!?;])\s+|\n+/).map(s=>s.replace(/∯/g,'.'));
    for (const rawSentence of sentences) {
      const chunks=rawSentence.split(/\b(?:but|however|whereas|mais|cependant|tandis que)\b/i);
      for (const rawClause of chunks) {
        const clause=clean(rawClause);if(!clause)continue;
        const s=norm(clause);let matched=false;
        for (const [id,label,,pattern] of definitions) {
          pattern.lastIndex=0;
          for (const m of s.matchAll(pattern)) {
            const itemStart=s.lastIndexOf(',',m.index)+1, comma=s.indexOf(',',m.index+m[0].length);
            const item=s.slice(itemStart,comma<0?s.length:comma);
            let state=stateFor(s,m.index,m.index+m[0].length);
            // Un visuel de boutique n'est pas un graphisme intégré au jeu.
            promoRE.lastIndex=0;
            const promoItem=promoRE.test(item);promoRE.lastIndex=0;
            const prep=scopeRE.test(item) || (scopeRE.test(s) && /\b(?:only|solely|uniquement|seulement|not (?:included|used)|never (?:included|used)|absents?|non integres?|pas integres?)\b/.test(s));
            if (['visual','animation','sound','voice','text','translation'].includes(id) && prep) {matched=true;continue;}
            if (['visual','animation','sound','voice','text','translation'].includes(id) && promoItem) {matched=true;continue;}
            if (id==='visual' && /background\s+(?:music|sound|audio)/.test(item)) continue;
            if (id==='sound' && /^(?:audio|sound|sounds|son|sons)$/.test(m[0]) && /\b(?:voice|voices|voix|speech|tts|doublage)\b/.test(item)) continue;
            if (id==='text' && /text[- ]to[- ]speech|writing\s+code/.test(item)) continue;
            if (id==='text' && /\b(?:translat(?:ion|e|ed|ing)|traduction|localization|localisation)\b/.test(s) && /\b(?:only|solely|uniquement|seulement)\b/.test(s)) continue;
            hits.push({id,label,state,excerpt:clause});matched=true;
          }
        }
        if (!matched && !/^\W*(?:all|tout|tous|every|each|these|ces|the|le|la|les)?\s*(?:ai[- ]generated|generated|content|contenus?|assets?|outputs?|resultats?)\b.*\b(?:review|revu|refin|retravaill|edit|integrat|quality|qualite|direction)/.test(s) && !/\b(?:no ai|no generative ai|aucune ia|sans ia|not use ai|not used|no artificial intelligence)\b/.test(s)) {
          hits.push({id:'other',label:'Autres usages',state:stateFor(s,Math.max(0,s.search(/ai|ia|chatgpt/)),s.length),excerpt:clause});
        }
      }
    }
    const categories=definitions.map(([id,label,icon])=>{
      const found=hits.filter(h=>h.id===id), states=new Set(found.map(h=>h.state));
      let state='unmentioned';
      if(states.has('mentioned') && (states.has('denied')||states.has('removed'))) state='mixed';
      else if(states.has('mentioned'))state='mentioned';else if(states.has('uncertain'))state='uncertain';else if(states.has('removed'))state='removed';else if(states.has('denied'))state='denied';
      return {id,label,icon,state,evidence:[...new Set(found.map(h=>h.excerpt))]};
    });
    return {text,hits,categories};
  }
  function extractAI(doc) {
    const headings=[...doc.querySelectorAll('h2,h3')];
    const heading=headings.find(h=>/ai.generated content disclosure|contenu.*genere.*(?:ia|intelligence)|utilisation.*intelligence artificielle/i.test(norm(h.textContent)));
    if(!heading)return {found:false,target:null,...classifyAI('')};
    const parent=heading.closest('.game_area_description')||heading.parentElement;
    // Steam emploie aussi un paragraphe unique contenant l'introduction et la déclaration.
    const range=doc.createRange();range.setStartAfter(heading);
    const next=[...parent.querySelectorAll('h2,h3')].find(h=>h!==heading && (heading.compareDocumentPosition(h)&4));
    if(next)range.setEndBefore(next);else range.setEnd(parent,parent.childNodes.length);
    const fragment=range.cloneContents();fragment.querySelectorAll('script,style').forEach(n=>n.remove());
    fragment.querySelectorAll('br').forEach(n=>n.replaceWith('\n'));
    fragment.querySelectorAll('p,li,div').forEach(n=>n.append('\n'));
    let text=fragment.textContent.replace(/\r/g,'').replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();
    text=text.replace(/^(?:The developers? describe[^:\n]*:|L['’]équipe de développement décrit[^.\n]*[.:]|Les développeurs décrivent[^:\n]*:|Voici comment[^:\n]*:)\s*/i,'').trim();
    return {found:true,target:heading,...classifyAI(text)};
  }
  function parseDeck(doc) {
    const target=doc.querySelector('#steam_deck_compatibility, .steamdeck_compatibility, .steam_deck_compatibility, [class*="steamdeckcompatibility"]');
    const embedded=doc.querySelector('[data-hardwarecompatibility]');
    if(embedded) {
      try {
        const h=JSON.parse(embedded.getAttribute('data-hardwarecompatibility'));
        const status=({0:'Inconnu',1:'Non pris en charge',2:'Jouable',3:'Vérifié'})[h.resolved_category];
        if(status) {
          const messages={DefaultControllerConfigFullyFunctional:'Les fonctions du jeu sont accessibles à la manette.',ControllerGlyphsMatchDeckDevice:'Les indications correspondent aux commandes Steam Deck.',InterfaceTextIsLegible:'Les textes sont lisibles sur Steam Deck.',DefaultConfigurationIsPerformant:'La configuration par défaut convient au Steam Deck.',LauncherInteraction:'Le lanceur peut nécessiter le tactile ou le clavier virtuel.',TextInputNotAccessibleWithController:'Certaines saisies nécessitent le clavier virtuel.',InterfaceTextIsNotLegible:'Certains textes peuvent être petits.',UnsupportedAntiCheat:'Le système anti-triche est incompatible.'};
          const details=(h.resolved_items||[]).map(i=>{const k=String(i.loc_token||'').replace('#SteamDeckVerified_TestResult_','');return messages[k]||null}).filter(Boolean);
          return {status,detail:details.join(' · ')||(status==='Inconnu'?'Steam n’a pas terminé l’évaluation.':'Évaluation Steam Deck issue des données de cette fiche. Consultez les détails sur Steam.'),target};
        }
      } catch { /* Donnée absente ou format non reconnu : aucun statut deviné. */ }
    }
    if(!target)return {status:'Non indiqué',detail:'Statut absent de la fiche chargée.',target:null};
    const s=norm(target.textContent+' '+[...target.querySelectorAll('img')].map(n=>`${n.alt} ${n.src}`).join(' '));
    const status=/unsupported|non pris en charge|incompatible/.test(s)?'Non pris en charge':/verified|verifie|\bcompatible\b/.test(s)?'Vérifié':/playable|jouable/.test(s)?'Jouable':/unknown|inconnu|indetermine|non teste/.test(s)?'Inconnu':'Non indiqué';
    const detail=[...target.querySelectorAll('.steamdeck_compatibility_details, .steamdeck_compatibility_detail, li')].map(n=>clean(n.textContent)).filter(Boolean).join(' · ');
    return {status,detail:detail||(status==='Inconnu'?'Évaluation non terminée ou non disponible.':'Statut indiqué par Steam ; cliquez pour rejoindre la rubrique.'),target};
  }
  function parse(doc,href='') {
    const q=s=>doc.querySelector(s), qa=s=>[...doc.querySelectorAll(s)], txt=n=>clean(n?.textContent);
    const titleNode=q('#appHubAppName, .apphub_AppName');
    const ready=!!titleNode&&!q('#agecheck_form, .agegate_birthday_selector');
    const featureRoot=q('#category_block'),features=[...(featureRoot||doc).querySelectorAll('a.game_area_details_specs_ctn')];
    const ids=new Set(features.map(n=>{try{return new URL(n.getAttribute('href'),'https://store.steampowered.com').searchParams.get('category2')}catch{return null}}));
    const labels=features.map(n=>norm(txt(n))),has=(id,re)=>ids.has(String(id))||labels.some(l=>re.test(l));
    const modes=[];
    [[2,/single.player|solo/,'Solo'],[38,/online co.op|coop.*ligne/,'Coop en ligne'],[39,/shared.*co.op|split.*co.op|coop.*local/,'Coop locale'],[36,/online pvp|jcj.*ligne/,'PvP en ligne'],[37,/shared.*pvp|split.*pvp|jcj.*local/,'PvP local'],[27,/cross.platform multiplayer|multijoueur multiplateforme/,'Cross-play'],[20,/massively multiplayer|massivement multijoueur|^mmo$/,'MMO']].forEach(([i,r,l])=>{if(has(i,r))modes.push(l)});
    if(has(9,/^co.op$|^cooperation$/)&&!modes.some(m=>m.startsWith('Coop')))modes.push('Coop (type non indiqué)');
    if(has(1,/^multi.player$|^multijoueur$/)&&!modes.some(m=>/Coop|PvP|MMO/.test(m)))modes.push('Multijoueur');
    if(q('.vr_required')||/vr.only|vr required|casque vr requis/.test(norm(txt(q('.game_area_purchase_game')))))modes.push('VR obligatoire');
    else if(has(53,/vr support|prise en charge.*vr/))modes.push('VR compatible');
    const langTable=q('table.game_language_options');
    const languages=langTable?[...langTable.querySelectorAll('tr')].flatMap(tr=>{
      const t=[...tr.querySelectorAll('td')];if(t.length<3)return[];
      const check=n=>/[✔✓]/.test(n?.textContent||'')||!!n?.querySelector('img[src*="ico_bluecheck"],.checkmark');
      return [{name:txt(t[0]),interface:check(t[1]),audio:check(t[2]),subtitles:check(t[3])}];
    }):[];
    const fr=l=>/^(french|francais)\b/.test(norm(l.name)),en=l=>/^(english|anglais)\b/.test(norm(l.name));
    const frenchName=name=>({'english':'Anglais','french':'Français','japanese':'Japonais','portuguese - brazil':'Portugais · Brésil','portuguese - portugal':'Portugais · Portugal','spanish - spain':'Espagnol','german':'Allemand','russian':'Russe','simplified chinese':'Chinois simplifié','traditional chinese':'Chinois traditionnel','korean':'Coréen'}[norm(name)]||name);
    const priority=items=>{const a=items.find(fr),b=items.find(en);return a?'Français':b?'Anglais':items.length?items.map(l=>frenchName(l.name)).join(' · '):'Non indiqué'};
    const audio=languages.filter(l=>l.audio),interfaces=languages.filter(l=>l.interface);
    const platform=qa('.game_area_purchase_platform .platform_img, .sysreq_tab, .sysreq_content[data-os]');
    const os=new Set();platform.forEach(n=>{const v=`${n.className} ${n.dataset.os||''}`;if(/\bwin\b/i.test(v))os.add('Windows');if(/\bmac\b/i.test(v))os.add('macOS');if(/\blinux\b/i.test(v))os.add('Linux')});
    const demoArea=q('#demo_block, .demo_above_purchase, .download_demo_buttons_ctn');
    const demoLink=qa('#demo_block a, .demo_above_purchase a, .download_demo_buttons_ctn a, .game_area_purchase_game a').find(a=>/demo|demonstration/.test(norm(txt(a)))&&/\/app\/\d+|rungameid|install\/\d+/.test(a.getAttribute('href')||''));
    const reviewRoot=q('#userReviews, .user_reviews'),rows=[...(reviewRoot||doc).querySelectorAll('.user_reviews_summary_row')];
    const reviews=rows.map(row=>{
      const label=txt(row.querySelector('.subtitle')),summary=txt(row.querySelector('.game_review_summary, .summary'));
      const tooltip=row.getAttribute('data-tooltip-html')||row.getAttribute('data-tooltip-text')||row.querySelector('[data-tooltip-html]')?.getAttribute('data-tooltip-html')||'';
      const d=new DOMParser().parseFromString(tooltip,'text/html');const detail=txt(d.body),s=norm(label);
      const recent=/recent/.test(s),global=/all reviews|overall|toutes les eval|evaluations globales/.test(s);
      const languageSpecific=!recent&&!global&&/reviews|eval|francais|english|anglais|language|langue/.test(s);
      return {target:q('#app_reviews_hash, #app_reviews, #review_summary')||reviewRoot,label:recent?'Avis récents':languageSpecific?label.replace(/:\s*$/,''):'Avis globaux',summary,count:txt(row.querySelector('.responsive_hidden, .review_count')),percentage:detail.match(/\d+(?:[.,]\d+)?\s*%/)?.[0]||'',detail,recent,languageSpecific};
    }).filter((r,i,a)=>a.findIndex(o=>o.label===r.label&&o.summary===r.summary&&o.count===r.count)===i);
    const earlyNode=q('.early_access_header,.early_access_banner,#earlyAccessHeader');
    return {title:txt(titleNode)||'Fiche Steam',appid:href.match(/\/app\/(\d+)/)?.[1]||'',ready,date:txt(q('.release_date .date,.grid_content.grid_date'))||'Non indiquée',early:earlyNode?'Oui':ready?'Non':'Non indiqué',demo:demoArea||demoLink?'Disponible':'Non repérée',modes:modes.join(' · ')||'Non indiqué',languages,interface:langTable?priority(interfaces):'Non indiqué',voices:!langTable?'Non indiqué':audio.length?priority(audio):'Aucune voix',languageDetails:languages,platform:[...os].join(' · ')||'Non indiqué',reviews,deck:parseDeck(doc),ai:extractAI(doc),targets:{date:q('.release_date,.grid_content.grid_date'),early:earlyNode,demo:demoArea||demoLink,modes:featureRoot,languages:langTable,platform:q('.sys_req h2')||q('#game_area_sys_req, .sys_req, .sysreq_contents, .game_area_sys_req, .sysreq_tabs'),reviews:q('#app_reviews_hash, #app_reviews, #review_summary')||reviewRoot}};
  }
  globalThis.CentuSteam={parse,classifyAI,definitions:definitions.map(([id,label,icon])=>({id,label,icon}))};
})();
