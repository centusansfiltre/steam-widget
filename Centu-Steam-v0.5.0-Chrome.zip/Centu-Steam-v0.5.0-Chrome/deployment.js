// Source officielle du catalogue vidéo ; données JSON uniquement.
globalThis.CentuDeployment=Object.freeze({catalogURL:'https://raw.githubusercontent.com/centusansfiltre/steam-widget/main/videos.json',channelURL:'https://www.youtube.com/@centusansfiltre'});
