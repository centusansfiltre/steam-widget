const api=globalThis.browser||globalThis.chrome;let lang=CentuI18n.detect(navigator.language);
api.storage.local.get('centuSteamV2').then(s=>{const v=s.centuSteamV2?.uiLanguage;if(v&&v!=='auto')lang=v;document.documentElement.lang=lang;for(const n of document.querySelectorAll('[data-i18n]'))n.textContent=CentuI18n.translate(n.textContent,lang)});
'use strict';
document.querySelector('#open').addEventListener('click',async()=>{
 const api=globalThis.browser||globalThis.chrome;
 try {const [tab]=await api.tabs.query({active:true,currentWindow:true});await api.tabs.sendMessage(tab.id,{type:'centu-open'});window.close();}
 catch{document.querySelector('#message').textContent=lang==='en'?'Open a game page on store.steampowered.com and reload it if necessary.':'Ouvrez une fiche de jeu sur store.steampowered.com, puis actualisez-la si nécessaire.';}
});
