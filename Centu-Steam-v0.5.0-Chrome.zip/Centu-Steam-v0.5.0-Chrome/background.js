'use strict';
importScripts('deployment.js','catalog-core.js');
const api=globalThis.chrome;
const TTL=6*60*60*1000,empty=()=>({version:1,games:{}});
let lastSync={ok:true};
let pending=null,controller=null,generation=0,enabledOverride=null;
const enabled=s=>enabledOverride!==false&&s.centuVideoEnabled!==false&&s.centuSteamV2?.visible?.videos!==false;
function stop(){generation++;controller?.abort();controller=null;pending=null}
async function getCatalog(force=false){
 const s=await api.storage.local.get(['centuVideoCache','centuSteamV2','centuVideoEnabled']);
 if(!enabled(s)){lastSync={ok:false,reason:"disabled"};return empty();}
 const source=CentuDeployment.catalogURL;if(!source){lastSync={ok:false,reason:"source"};return empty();}
 const url=CentuCatalog.sourceURL(source),cache=s.centuVideoCache;
 if(!force&&cache?.url===url&&Date.now()-cache.checkedAt<TTL){lastSync={ok:!cache.failed,checkedAt:cache.checkedAt};return cache.catalog;}
 if(pending)return pending;
 const epoch=++generation,abort=new AbortController();controller=abort;
 const timeout=setTimeout(()=>abort.abort(),15000);
 const valid=async()=>{const latest=await api.storage.local.get(['centuSteamV2','centuVideoEnabled']);return epoch===generation&&enabled(latest)};
 pending=(async()=>{
  try{
   if(!await valid())return empty();
   const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-cache',redirect:'error',signal:abort.signal});
   if(!response.ok)throw Error('HTTP '+response.status);
   if(Number(response.headers.get('content-length'))>CentuCatalog.MAX_BYTES)throw Error('Catalog too large');
   const reader=response.body.getReader(),parts=[];let length=0;
   while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>CentuCatalog.MAX_BYTES){await reader.cancel();throw Error('Catalog too large')}parts.push(value)}
   const bytes=new Uint8Array(length);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length}
   const catalog=CentuCatalog.normalize(JSON.parse(new TextDecoder().decode(bytes)));
   if(!await valid())return empty();
   lastSync={ok:true,checkedAt:Date.now()};
   await api.storage.local.set({centuVideoCache:{url,checkedAt:lastSync.checkedAt,catalog}});return catalog;
  }catch{
   if(!await valid())return empty();
   const fallback=cache?.url===url?cache.catalog:empty();
   lastSync={ok:false,reason:"network",checkedAt:Date.now()};
   await api.storage.local.set({centuVideoCache:{url,checkedAt:Date.now(),failed:true,catalog:fallback}});return fallback;
  }finally{clearTimeout(timeout);if(epoch===generation){pending=null;controller=null}}
 })();return pending;
}
api.storage.onChanged?.addListener((changes,area)=>{if(area==='local'&&(changes.centuSteamV2?.newValue?.visible?.videos===false||changes.centuVideoEnabled?.newValue===false)){enabledOverride=false;stop()}else if(area==='local'&&(changes.centuSteamV2?.newValue?.visible?.videos===true||changes.centuVideoEnabled?.newValue===true))enabledOverride=true});
api.runtime.onMessage.addListener((m,sender,reply)=>{
 if(sender.id!==api.runtime.id)return;
 if(m?.type==='centu-catalog-refresh'){getCatalog(true).then(catalog=>reply({...lastSync,catalog}),()=>reply({ok:false,reason:'network'}));return true}
 if(m?.type==='centu-catalog-get'){getCatalog().then(reply,()=>reply(empty()));return true}
 if(m?.type==='centu-catalog-enabled'&&typeof m.enabled==='boolean'){
  enabledOverride=m.enabled;if(!m.enabled)stop();
  api.storage.local.set({centuVideoEnabled:m.enabled}).then(()=>reply({ok:true}),()=>reply({ok:false}));return true;
 }
});
