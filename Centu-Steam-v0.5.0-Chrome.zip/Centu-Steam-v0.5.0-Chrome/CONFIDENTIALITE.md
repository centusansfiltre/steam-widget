# Confidentialité — v0.5.0

La fiche Steam et sa déclaration IA sont lues et interprétées localement. Aucun service d’IA, télémétrie, compte ou outil d’analyse n’est utilisé.

Lorsque les vidéos sont activées, l’extension télécharge le catalogue complet depuis https://raw.githubusercontent.com/centusansfiltre/steam-widget/main/videos.json. Aucun Steam ID, contenu de fiche ou historique de navigation n’est transmis. GitHub reçoit les informations techniques habituelles d’une connexion, dont l’adresse IP. Les cookies et le référent sont omis.

Le catalogue et les préférences sont conservés sur votre appareil. La vérification se fait automatiquement à l’usage toutes les six heures. Le bouton Actualiser les vidéos permet de forcer cette vérification. En cas d’échec, le dernier catalogue téléchargé reste disponible. Aucun catalogue n’est embarqué dans l’extension.

Désactiver les vidéos masque les liens et arrête les requêtes au catalogue, y compris une requête en cours. Aucun code distant n’est exécuté : le JSON est validé et seuls des liens YouTube sont acceptés.
