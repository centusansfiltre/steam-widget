/* Data-only catalog. No remote scripts, HTML, images or navigation data. */
(()=>{
const MAX_BYTES=4*1024*1024;
function normalize(raw){
 if(!raw||raw.version!==1||!raw.games||typeof raw.games!=='object'||Array.isArray(raw.games))throw Error('Invalid catalog');
 const games={};const entries=Object.entries(raw.games);if(entries.length>20000)throw Error('Catalog too large');
 for(const[id,items]of entries){if(!/^\d{1,12}$/.test(id)||!Array.isArray(items)||items.length>20)throw Error('Invalid game entry');
 games[id]=items.map(v=>{if(!v||typeof v.url!=='string')throw Error('Invalid video');const u=new URL(v.url);
 if(u.protocol!=='https:'||u.username||u.password||u.port||!['www.youtube.com','youtube.com','youtu.be'].includes(u.hostname))throw Error('YouTube URL required');
 if(u.hostname==='youtu.be'){if(!/^\/[\w-]{11}$/.test(u.pathname))throw Error('Invalid video ID')}else if(u.pathname!=='/watch'||!/^[-\w]{11}$/.test(u.searchParams.get('v')||''))throw Error('Invalid video ID');
 if(v.title!=null&&typeof v.title!=='string')throw Error('Invalid title');return {title:(v.title||'').slice(0,160),url:u.href};});
 }return {version:1,games};
}
function sourceURL(raw){const u=new URL(raw);if(u.protocol!=='https:'||u.hostname!=='raw.githubusercontent.com'||u.username||u.password||u.port||u.search||u.hash||u.pathname.split('/').filter(Boolean).length<4)throw Error('Use a public raw.githubusercontent.com JSON URL');return u.href}
globalThis.CentuCatalog={normalize,sourceURL,MAX_BYTES};
})();
