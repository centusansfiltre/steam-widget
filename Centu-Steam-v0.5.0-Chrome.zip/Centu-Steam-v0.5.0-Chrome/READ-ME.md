# Centu Sans Filtre — Steam v0.5.0 — Chrome

1. Extraire le ZIP dans un dossier conservé sur votre ordinateur.
2. Ouvrir chrome://extensions et activer le mode développeur.
3. Cliquer sur Charger l’extension non empaquetée et sélectionner le dossier contenant manifest.json.
4. Actualiser les onglets Steam déjà ouverts.

Pour remplacer une version locale existante : remplacer les fichiers de son dossier, puis cliquer sur Actualiser sur la carte de l’extension dans chrome://extensions. Actualiser ensuite la fiche Steam.

Le catalogue vidéo vient directement du dépôt GitHub officiel et est conservé en cache local pendant six heures. Aucun fichier videos.json local à modifier. Personnalisation → Vidéos Centu → Actualiser les vidéos force la récupération. Le toggle désactive aussi les requêtes réseau.
